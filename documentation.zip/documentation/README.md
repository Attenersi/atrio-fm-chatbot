# Central Documentation Folder

This folder contains a centralized copy of project documentation files so they are available in one place.

Source-of-truth files still live in their original locations (`/`, `docs/`, `backend/`).
Use this directory as a consolidated reading bundle.

## Root docs

- [README.md](README.md)
- [README.nl.md](README.nl.md)

## Role guides

- [docs/README_users.md](docs/README_users.md)
- [docs/README_users.nl.md](docs/README_users.nl.md)
- [docs/README_managers.md](docs/README_managers.md)
- [docs/README_managers.nl.md](docs/README_managers.nl.md)
- [docs/README_developers.md](docs/README_developers.md)
- [docs/README_developers.nl.md](docs/README_developers.nl.md)

## Technical and policy docs

- [docs/fine_tuning_data.md](docs/fine_tuning_data.md)
- [docs/validation_checklist.md](docs/validation_checklist.md)
- [docs/github_publish_checklist.md](docs/github_publish_checklist.md)

## Backend runtime docs

- [backend/README.md](backend/README.md)
- [backend/README.nl.md](backend/README.nl.md)
# FM Chatbot

Language: **English** | [Nederlands](README.nl.md)

FM Chatbot is a Facility Management assistant platform with:

- Next.js frontend (`frontend/`)
- FastAPI backend (`backend/`)
- SQLite operational data store (users, sessions, tickets, gaps, training rows)
- Chroma vector index for retrieval (RAG)
- OpenAI-compatible LLM provider integration

## What the app does

1. A user asks a question in chat.
2. Backend retrieves relevant FM document context.
3. LLM generates structured output (classification + response).
4. Backend applies deterministic guardrails and ticketing rules.
5. If needed, one or more tickets are created.
6. Interaction is logged for analytics, review, and training-quality workflows.

## Documentation map

- End users: [`docs/README_users.md`](docs/README_users.md)
- Managers/Admins: [`docs/README_managers.md`](docs/README_managers.md)
- Developers: [`docs/README_developers.md`](docs/README_developers.md)
- Backend runtime reference: [`backend/README.md`](backend/README.md)
- Fine-tuning data lifecycle: [`docs/fine_tuning_data.md`](docs/fine_tuning_data.md)
- Validation checklist: [`docs/validation_checklist.md`](docs/validation_checklist.md)

## Quick start (Windows / PowerShell)

### 1) Backend

```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

Create `backend/.env` from `backend/.env.example` and set required values.

### 2) Frontend

```powershell
cd ..\frontend
npm install
```

Create `frontend/.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### 3) Ingest FM docs (first run and after doc changes)

```powershell
cd ..\backend
.\venv\Scripts\python.exe -m app.ingest
```

### 4) Run backend

```powershell
.\venv\Scripts\python.exe -m app.main
```

### 5) Run frontend

```powershell
cd ..\frontend
npm run dev
```

Open `http://localhost:3000`.

## Main product areas

- `/chat` - user conversations and automated ticket creation
- `/dashboard` - ticket list, stats, filters, status updates
- `/help` - in-app help and operational guidance
- `/admin` - docs, users, knowledge gaps, training review, quality tools
- `/admin/training-quality` - eval runs, analyzer suggestions, prompt overrides
- `/admin/llm` - LLM profile management and task defaults

## Quality and testing

Run the RAG evaluation suite:

```powershell
cd backend
.\venv\Scripts\python.exe -u test_rag.py --cases-file atrio_test_cases.json --output test_results_full.json
```

Interpret:

- `pass_rate` (all cases, including transport failures)
- `api_ok_pass_rate` (logic quality when API responds correctly)

See [`backend/test_runbook.md`](backend/test_runbook.md) for troubleshooting and rerun strategy.

# FM Chatbot

Taal: [English](README.md) | **Nederlands**

FM Chatbot is een Facility Management-assistentplatform met:

- Next.js frontend (`frontend/`)
- FastAPI backend (`backend/`)
- SQLite voor operationele data (gebruikers, sessies, tickets, lacunes, trainingsregels)
- Chroma vectorindex voor retrieval (RAG)
- OpenAI-compatibele LLM-providerintegratie

## Wat de app doet

1. Een gebruiker stelt een vraag in de chat.
2. De backend haalt relevante gebouwdocumentatie op.
3. Het model genereert een gestructureerd resultaat (classificatie + antwoord).
4. Backend-guardrails bepalen of ticketing nodig is.
5. Indien nodig worden een of meerdere tickets aangemaakt.
6. De interactie wordt gelogd voor review en kwaliteitsverbetering.

## Documentatiemap

- Eindgebruikers: [`docs/README_users.nl.md`](docs/README_users.nl.md)
- Managers/Admins: [`docs/README_managers.nl.md`](docs/README_managers.nl.md)
- Developers: [`docs/README_developers.nl.md`](docs/README_developers.nl.md)
- Backend referentie: [`backend/README.nl.md`](backend/README.nl.md)
- Fine-tuning lifecycle (EN): [`docs/fine_tuning_data.md`](docs/fine_tuning_data.md)
- Validatiechecklist (EN): [`docs/validation_checklist.md`](docs/validation_checklist.md)

## Snelle start (Windows / PowerShell)

### 1) Backend

```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

Maak `backend/.env` op basis van `backend/.env.example` en vul verplichte variabelen in.

### 2) Frontend

```powershell
cd ..\frontend
npm install
```

Maak `frontend/.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### 3) Ingest FM-documenten (eerste run en na wijzigingen)

```powershell
cd ..\backend
.\venv\Scripts\python.exe -m app.ingest
```

### 4) Start backend

```powershell
.\venv\Scripts\python.exe -m app.main
```

### 5) Start frontend

```powershell
cd ..\frontend
npm run dev
```

Open `http://localhost:3000`.

## Belangrijkste productzones

- `/chat` - gesprekken en automatische ticketaanmaak
- `/dashboard` - ticketlijst, statistieken, filters en statussen
- `/help` - in-app handleiding
- `/admin` - documenten, users, kennislacunes, training review
- `/admin/training-quality` - eval runs, analyzer, prompt overrides
- `/admin/llm` - LLM-profielen en task defaults

## Kwaliteit en testen

Voer de RAG-evaluatiesuite uit:

```powershell
cd backend
.\venv\Scripts\python.exe -u test_rag.py --cases-file atrio_test_cases.json --output test_results_full.json
```

Interpreteer:

- `pass_rate` (alle cases)
- `api_ok_pass_rate` (logica wanneer API-calls slagen)

Zie [`backend/test_runbook.md`](backend/test_runbook.md) voor troubleshooting.

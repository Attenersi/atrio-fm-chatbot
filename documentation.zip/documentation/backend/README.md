# Backend

Language: **English** | [Nederlands](README.nl.md)

FastAPI service for:

- auth and session handling
- chat orchestration (sync and stream)
- ticket CRUD and status changes
- admin operations (users, docs, gaps, training quality)
- training-data capture and review workflows

## Setup

```powershell
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

## Environment

Create `backend/.env` from `backend/.env.example`.

Required (typical):

- `NVIDIA_API_KEY`
- `NVIDIA_BASE_URL`
- `LLM_MODEL`
- `EMBED_MODEL`
- `DOCS_DIR`
- `CHROMA_DIR`
- `SQLITE_DB_PATH`
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

Optional:

- SMTP (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM`)
- bootstrap user (`AUTH_BOOTSTRAP_USER_USERNAME`, `AUTH_BOOTSTRAP_USER_PASSWORD`)

## Run

Development:

```powershell
.\venv\Scripts\python.exe -m app.main
```

Alternative:

```powershell
uvicorn app.main:app --reload --port 8000
```

## Ingest documents

```powershell
.\venv\Scripts\python.exe -m app.ingest
```

This rebuilds the vector index from `docs_fm/` (or configured docs path).

## Core modules

- `app/main.py` - API routes + orchestration
- `app/rag.py` - retrieval and generation pipeline
- `app/classifier.py` - parsing/normalization of model output
- `app/database.py` - SQLite schema and queries
- `app/ingest.py` - chunking and embedding ingestion
- `app/llm.py` - LLM and embedding API wrappers
- `app/prompt_analyzer.py` - suggestion analysis
- `app/prompt_consolidator.py` - rule merge helpers
- `app/prompt_replay.py` - replay evaluation helpers

## API groups

- health: `/health`, `/health/llm`
- auth: `/api/auth/*`
- chat: `/api/chat`, `/api/chat/stream`, `/api/chat/history`
- tickets: `/api/tickets*`
- admin: `/api/admin/*`
- training quality: `/api/admin/training-quality/*`
- llm profiles: `/api/admin/llm/*`

## Quality testing

Run evaluation:

```powershell
.\venv\Scripts\python.exe -u test_rag.py --cases-file atrio_test_cases.json --output test_results_full.json
```

Track:

- `pass_rate`
- `api_ok_pass_rate` / `api_ok_only`

Reference: `backend/test_runbook.md`.

## Maintenance notes

- Utilities: `backend/scripts/`
- Migrations/helpers: `backend/app/db_migrations.py`
- Publish safety checklist: `../docs/github_publish_checklist.md`

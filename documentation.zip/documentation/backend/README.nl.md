# Backend

Taal: [English](README.md) | **Nederlands**

FastAPI-service voor:

- authenticatie en sessies
- chatorchestratie (sync + stream)
- ticketbeheer en statusupdates
- adminoperaties (users, docs, gaps, training quality)
- logging voor training- en kwaliteitsworkflows

## Setup

```powershell
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

## Omgevingsvariabelen

Maak `backend/.env` vanuit `backend/.env.example`.

Gebruikelijk verplicht:

- `NVIDIA_API_KEY`
- `NVIDIA_BASE_URL`
- `LLM_MODEL`
- `EMBED_MODEL`
- `DOCS_DIR`
- `CHROMA_DIR`
- `SQLITE_DB_PATH`
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

Optioneel:

- SMTP (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM`)
- bootstrap user (`AUTH_BOOTSTRAP_USER_USERNAME`, `AUTH_BOOTSTRAP_USER_PASSWORD`)

## Starten

Development:

```powershell
.\venv\Scripts\python.exe -m app.main
```

Alternatief:

```powershell
uvicorn app.main:app --reload --port 8000
```

## Document ingest

```powershell
.\venv\Scripts\python.exe -m app.ingest
```

Dit bouwt de vectorindex opnieuw op vanuit `docs_fm/` (of het geconfigureerde docs-pad).

## Kernmodules

- `app/main.py` - routes + orchestratie
- `app/rag.py` - retrieval en generatie
- `app/classifier.py` - parsing/normalisatie modeloutput
- `app/database.py` - SQLite schema en queries
- `app/ingest.py` - chunking en embedding ingest
- `app/llm.py` - LLM/embedding clients
- `app/prompt_analyzer.py` - suggestie-analyse
- `app/prompt_consolidator.py` - merge helpers
- `app/prompt_replay.py` - replay helpers

## API-groepen

- health: `/health`, `/health/llm`
- auth: `/api/auth/*`
- chat: `/api/chat`, `/api/chat/stream`, `/api/chat/history`
- tickets: `/api/tickets*`
- admin: `/api/admin/*`
- training quality: `/api/admin/training-quality/*`
- llm-profielen: `/api/admin/llm/*`

## Kwaliteitstests

```powershell
.\venv\Scripts\python.exe -u test_rag.py --cases-file atrio_test_cases.json --output test_results_full.json
```

Volg:

- `pass_rate`
- `api_ok_pass_rate` / `api_ok_only`

Referentie: `backend/test_runbook.md`.

## Onderhoud

- Utilities: `backend/scripts/`
- Migraties/helpers: `backend/app/db_migrations.py`
- Publicatiechecklist: `../docs/github_publish_checklist.md`

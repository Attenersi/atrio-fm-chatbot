# Developer Guide

Language: **English** | [Nederlands](README_developers.nl.md)

## Project overview

FM chatbot stack:

- frontend: Next.js app (`frontend/`)
- backend: FastAPI service (`backend/`)
- operational DB: SQLite
- vector DB: Chroma (RAG retrieval)
- LLM integration: OpenAI-compatible provider

## Local setup (Windows / PowerShell)

### Backend

```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

Configure `backend/.env` (start from `backend/.env.example`).

### Frontend

```powershell
cd ..\frontend
npm install
```

Set `frontend/.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### Ingest and run

```powershell
cd ..\backend
.\venv\Scripts\python.exe -m app.ingest
.\venv\Scripts\python.exe -m app.main
```

In another terminal:

```powershell
cd frontend
npm run dev
```

## Architecture and request flow

### Chat flow

1. frontend posts to `/api/chat` or `/api/chat/stream`
2. backend retrieves context from Chroma
3. LLM returns structured output
4. backend finalization applies deterministic rules
5. ticket(s) may be created
6. event is logged for training and quality workflows

### Main backend modules

- `backend/app/main.py` - API routes and orchestration
- `backend/app/rag.py` - retrieval and generation pipeline
- `backend/app/classifier.py` - output parsing and normalization
- `backend/app/database.py` - schema and persistence
- `backend/app/ingest.py` - document ingestion and embeddings
- `backend/app/prompt_analyzer.py` - suggestion generation
- `backend/app/prompt_consolidator.py` - merge helpers
- `backend/app/prompt_replay.py` - replay testing helpers
- `backend/app/llm_profiles.py` - provider profile management

## API surface (high-level)

Defined in `backend/app/main.py`:

- health: `/health`, `/health/llm`
- auth: `/api/auth/*`
- chat: `/api/chat`, `/api/chat/stream`, `/api/chat/history`
- tickets: `/api/tickets*`
- admin core: `/api/admin/*`
- training quality: `/api/admin/training-quality/*`
- llm profiles: `/api/admin/llm/*`

## Where to change behavior

- prompt composition and retrieval: `backend/app/rag.py`
- parsing/fallback handling: `backend/app/classifier.py`
- ticket heuristics and final payload rules: `backend/app/main.py`
- db schema and migrations: `backend/app/database.py`, `backend/app/db_migrations.py`

## Quality workflow

### Evaluation

```powershell
cd backend
.\venv\Scripts\python.exe -u test_rag.py --cases-file atrio_test_cases.json --output test_results_full.json
```

Read both:

- `pass_rate` (all outcomes)
- `api_ok_pass_rate` (logic quality when API succeeds)

### Admin quality loop

In `/admin/training-quality`:

- run eval
- inspect mismatch groups
- analyze suggestions
- apply/rollback/consolidate prompt overrides
- replay affected examples

## Adding/updating FM knowledge

1. Edit files in `backend/docs_fm/` (or configured docs dir)
2. Reindex (`python -m app.ingest` or admin reindex endpoint)
3. Run targeted tests
4. Validate via chat and knowledge-gap backlog

## Related specs

- [`docs/fine_tuning_data.md`](fine_tuning_data.md)
- [`backend/test_runbook.md`](../backend/test_runbook.md)

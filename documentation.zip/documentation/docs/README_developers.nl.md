# Developer Handleiding

Taal: [English](README_developers.md) | **Nederlands**

## Projectoverzicht

FM chatbot-stack:

- frontend: Next.js (`frontend/`)
- backend: FastAPI (`backend/`)
- operationele DB: SQLite
- vector DB: Chroma (RAG retrieval)
- modelprovider: OpenAI-compatibel endpoint

## Lokale setup (Windows / PowerShell)

### Backend

```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

Configureer `backend/.env` vanuit `backend/.env.example`.

### Frontend

```powershell
cd ..\frontend
npm install
```

`frontend/.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### Ingest + run

```powershell
cd ..\backend
.\venv\Scripts\python.exe -m app.ingest
.\venv\Scripts\python.exe -m app.main
```

In tweede terminal:

```powershell
cd frontend
npm run dev
```

## Architectuur en requestflow

### Chatflow

1. frontend post naar `/api/chat` of `/api/chat/stream`
2. backend haalt context op uit Chroma
3. model geeft gestructureerde output terug
4. finalisatie past deterministische regels toe
5. ticket(s) kunnen worden aangemaakt
6. event wordt gelogd voor training/kwaliteit

### Belangrijkste backendmodules

- `backend/app/main.py` - routes + orkestratie
- `backend/app/rag.py` - retrieval + generatie
- `backend/app/classifier.py` - parsing/normalisatie
- `backend/app/database.py` - schema + persistence
- `backend/app/ingest.py` - chunking + embeddings
- `backend/app/prompt_analyzer.py` - suggesties
- `backend/app/prompt_consolidator.py` - merge helpers
- `backend/app/prompt_replay.py` - replay helpers
- `backend/app/llm_profiles.py` - providerprofielen

## API-oppervlak (hoog niveau)

In `backend/app/main.py`:

- health: `/health`, `/health/llm`
- auth: `/api/auth/*`
- chat: `/api/chat`, `/api/chat/stream`, `/api/chat/history`
- tickets: `/api/tickets*`
- admin: `/api/admin/*`
- training quality: `/api/admin/training-quality/*`
- llm profiles: `/api/admin/llm/*`

## Waar gedrag aanpassen

- prompt/retrieval: `backend/app/rag.py`
- parsing/fallback: `backend/app/classifier.py`
- ticketheuristiek/finalisatie: `backend/app/main.py`
- schema/migraties: `backend/app/database.py`, `backend/app/db_migrations.py`

## Kwaliteitsworkflow

### Evaluatie

```powershell
cd backend
.\venv\Scripts\python.exe -u test_rag.py --cases-file atrio_test_cases.json --output test_results_full.json
```

Lees beide:

- `pass_rate`
- `api_ok_pass_rate` (`api_ok_only`)

### Admin quality loop

In `/admin/training-quality`:

- eval draaien
- mismatch-groepen analyseren
- suggesties beoordelen
- overrides toepassen/terugdraaien/samenvoegen
- replayen op relevante voorbeelden

## FM-kennis toevoegen/updaten

1. docs aanpassen in `backend/docs_fm/` (of geconfigureerd docs-pad)
2. reindex draaien
3. gerichte tests uitvoeren
4. valideren via chat en knowledge-gap backlog

## Gerelateerde specificaties

- [`docs/fine_tuning_data.md`](fine_tuning_data.md)
- [`backend/test_runbook.md`](../backend/test_runbook.md)
